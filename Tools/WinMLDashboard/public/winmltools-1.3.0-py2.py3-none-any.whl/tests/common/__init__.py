import os

temp_model_path = os.path.join(os.path.abspath('.'), '..\\models\\temp')