import unittest
import winmltools
from onnxmltools.proto import onnx_proto
import onnx
import os
import subprocess
import random
from .._utils import *

share = '\\\\redmond\\1windows\\TestContent\\CORE\\SiGMa\\GRFX\\WinML\\RS5\\models\\onnx-1.3'

class QuantizerTest(unittest.TestCase):
    def _verify_smaller(self, model_path, quantized_model_path):
        '''
           verify that model is smaller than before
        '''
        model_size = os.path.getsize(model_path)
        quantized_size = os.path.getsize(quantized_model_path)
        print('{} size: {} bytes'.format(model_path, model_size))
        print('{} size: {} bytes'.format(quantized_model_path, quantized_size))
        self.assertTrue(model_size > quantized_size)

    def _verify_quantize_model(self, model, name):
        temp_dir = os.path.join(os.path.abspath('.'), 'temp')
        if not os.path.isdir(temp_dir):
            os.makedirs(temp_dir)
        model_path = temp_dir + name + '.onnx'
        dq_path = temp_dir + name + '-quantized.onnx'
        cast_dq_path = temp_dir + name + '-rs5-quantized.onnx'
        with open(model_path, 'wb') as input_file:
            input_file.write(model.SerializeToString())
            input_file.close()
        winmltools.utils.quantize(model_path, dq_path)
        winmltools.utils.quantize(model_path, cast_dq_path)
        self._verify_smaller(model_path, dq_path)
        self._verify_smaller(model_path, cast_dq_path)


    def test_dequantize_linear(self):
        '''
            Testing DequantizeLinear operator weight packing
        '''
        resnet_model_path = share + '\\coreml_MNIST.onnx'
        quantized_result_path = os.path.join(temp_model_path, 'coreml_MNIST-dq.onnx')
        if not os.path.isdir(temp_model_path):
            os.makedirs(temp_model_path)
        winmltools.utils.quantize(resnet_model_path, quantized_result_path, per_channel=True, nbits=8, use_dequantize_linear=True)
        # verify that model is smaller than before
        self._verify_smaller(resnet_model_path, quantized_result_path)

        # verify that the model contains com.microsoft opset with version >= 1
        model = onnx.load_model(quantized_result_path)
        opset = next((opset for opset in model.opset_import if opset.domain == 'com.microsoft' and opset.version >= 1), None)
        self.assertFalse(opset is None)

        self._verify_smaller(resnet_model_path, quantized_result_path)
        self.assertEqual(run_model(quantized_result_path), 0)

    def test_csm(self):
        '''
            Testing cast-sub-mul operator weight packing
        '''
        resnet_model_path = share + '\\coreml_MNIST.onnx'
        quantized_result_path = os.path.join(temp_model_path, 'coreml_MNIST-csm.onnx')
        if not os.path.isdir(temp_model_path):
            os.makedirs(temp_model_path)
        winmltools.utils.quantize(resnet_model_path, quantized_result_path, per_channel=True, nbits=8, use_dequantize_linear=False)
        # verify that model is smaller than before
        self._verify_smaller(resnet_model_path, quantized_result_path)

        # verify that you can run the quantized model
        self.assertEqual(run_model(quantized_result_path), 0)

    def test_gemm(self):
        # create a model with simple inputs and outputs for matmul
        dims = [20,20]
        data_type = onnx_proto.TensorProto.FLOAT
        # inputs and outputs
        A = onnx.helper.make_tensor_value_info('A', data_type, dims)
        B = onnx.helper.make_tensor_value_info('B', data_type, dims)
        Y = onnx.helper.make_tensor_value_info('Y', data_type, dims)
        # nodes
        matmul = onnx.helper.make_node('Gemm', ['A', 'B'], ['Y'])
        # initializer
        init = onnx.helper.make_tensor('B', data_type, dims, [float(i) for i in range(400)])
        # call quantize
        graph = onnx.helper.make_graph([matmul], 'test_graph', [A, B], [Y], initializer=[init])
        model = onnx.helper.make_model(graph)
        self._verify_quantize_model(model, 'Gemm')

    def test_matmul(self):
        # create a model with simple inputs and outputs for matmul
        dims = [20,20]
        data_type = onnx_proto.TensorProto.FLOAT
        # inputs and outputs
        A = onnx.helper.make_tensor_value_info('A', data_type, dims)
        B = onnx.helper.make_tensor_value_info('B', data_type, dims)
        Y = onnx.helper.make_tensor_value_info('Y', data_type, dims)
        # nodes
        matmul = onnx.helper.make_node('MatMul', ['A', 'B'], ['Y'])
        # initializer
        init = onnx.helper.make_tensor('B', data_type, dims, [float(i) for i in range(400)])
        # call quantize
        graph = onnx.helper.make_graph([matmul], 'test_graph', [A, B], [Y], initializer=[init])
        model = onnx.helper.make_model(graph)
        self._verify_quantize_model(model, 'MatMul')

    def _verify_rnn_like_ops(self, op_name):
        data_type = onnx_proto.TensorProto.FLOAT
        input_size = 100
        hidden_size = 10
        W_dims = [1, 4 * hidden_size, input_size]
        R_dims = W_dims
        # create a model with simple LSTM model
        node = onnx.helper.make_node(
            op_name,
            inputs=['X', 'W', 'R'],
            outputs=['', 'Y'],
            hidden_size=hidden_size
        )

        # inputs and outputs
        X = onnx.helper.make_tensor_value_info('X', data_type, [1, 1, input_size])
        W = onnx.helper.make_tensor_value_info('W', data_type, W_dims)
        R = onnx.helper.make_tensor_value_info('R', data_type, R_dims)

        # initializer for W
        W_init = onnx.helper.make_tensor('W', data_type, W_dims,
            [random.random() for _ in range(4 * hidden_size * input_size)])
        R_init = onnx.helper.make_tensor('R', data_type, R_dims,
            [random.random() for _ in range(4 * hidden_size * input_size)])

        model = onnx.helper.make_model(onnx.helper.make_graph(
            [node], 'test_graph', [X,W,R], [], initializer=[W_init, R_init]))

        self._verify_quantize_model(model, op_name)

    def test_lstm(self):
        self._verify_rnn_like_ops('LSTM')

    def test_rnn(self):
        self._verify_rnn_like_ops('RNN')

    def test_gru(self):
        self._verify_rnn_like_ops('GRU')

if __name__ == '__main__':
    unittest.main()
