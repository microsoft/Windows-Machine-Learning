def hi_yo():
    return 1