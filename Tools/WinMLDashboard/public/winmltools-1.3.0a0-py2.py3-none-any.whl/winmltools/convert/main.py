# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------

from .common import utils


_default_build_number=17763 # RS5 build version


def build_number_to_opset(build):
    '''
        :param sdk: build number of OS in which a user wants to run onnx file.
        :return: opset number corresponding to the build number
    '''
    if build < 17134:
        raise ValueError('wrong build number {}. Minimum build allowed is 17134'.format(build))
    if build == 17134: # rs4
        return 1
    elif build <= 17763: # RS5
        return 7
    else: # 19H1
        return 8


def convert_sklearn(model, name=None, initial_types=None, build_number=_default_build_number, **kwarg):
    if not utils.sklearn_installed():
        raise RuntimeError('scikit-learn is not installed. Please install sci-kit learn to use this feature.')

    # import from onnxmltools
    from onnxmltools.convert.sklearn.convert import convert as _convert_sklearn

    # import from local sklearn to allow for overrides
    from . import sklearn

    opset = build_number_to_opset(build_number)
    return _convert_sklearn(model, name, initial_types=initial_types, target_opset=opset, **kwarg)


def convert_coreml(model, name=None, build_number=_default_build_number, **kwarg):
    if not utils.coreml_installed():
        raise RuntimeError('coremltools is not installed. Please install coremltools to use this feature.')

    # import from onnxmltools
    from onnxmltools.convert.coreml.convert import convert as _convert_coreml

    # import from local coreml to allow for overrides
    from . import coreml

    opset = build_number_to_opset(build_number)
    return _convert_coreml(model, name, target_opset=opset, **kwarg)


def convert_keras(model, name=None, build_number=_default_build_number, **kwarg):
    if not utils.keras_installed():
        raise RuntimeError('Keras is not installed. Please install Keras (>=2.0.0) to use this feature.')

    # import from onnxmltools
    from onnxmltools.convert.keras.convert import convert as _convert_keras

    # import from local keras to allow for overrides
    from . import keras

    opset = build_number_to_opset(build_number)
    return _convert_keras(model, name, target_opset=opset, **kwarg)


def convert_libsvm(model, name=None, build_number=_default_build_number, initial_types=None, **kwarg):
    if not utils.libsvm_installed():
        raise RuntimeError('libsvm is not installed. Please install libsvm to use this feature.')
    from .libsvm.convert import convert
    # not using build number for libsvm convert since it's only generating operators in ai.onnx.ml domain
    return convert(model, name=name, initial_types=initial_types, **kwarg)


def convert_xgboost(model, name=None, build_number=_default_build_number, initial_types=None, **kwarg):
    if not utils.xgboost_installed():
        raise RuntimeError(
            'xgboost not installed or not recent enough. Please install xgboost from github to use this feature.')

    from .xgboost.convert import convert
    # not using build number for xgboost convert since it's only generating operators in ai.onnx.ml domain
    return convert(model, name=name, initial_types=initial_types, **kwarg)


def convert_tensorflow(graph, name=None, continue_on_error=False, verbose=False, target=None,
                     build_number=_default_build_number, custom_op_handlers=None, custom_rewriter=None,
                     extra_opset=None, shape_override=None, inputs_as_nchw=None, output_names=None):
    """
    A simple wrap for tensorflow model converter, which is preliminary and subject to change.
    Args:
        :param graph: the frozen tensorflow model
        :param outputs: the model output names.
        :param opset: operator set version.
        :param name: the input model name, for description only.
        :param kwargs: extra args for tf2onnx converter.
        :return: ONNX model
    """
    try:
        import tensorflow
    except ImportError:
        raise RuntimeError(
            'Need Tensorflow python packages installed to enable its converter.'
        )

    opset = build_number_to_opset(build_number)
    import tf2onnx
    g = tf2onnx.tfonnx.process_tf_graph(graph, continue_on_error=continue_on_error, verbose=verbose, target=target,
                     opset=opset, custom_op_handlers=custom_op_handlers, custom_rewriter=custom_rewriter,
                     extra_opset=extra_opset, shape_override=shape_override, inputs_as_nchw=inputs_as_nchw, output_names=output_names)
    doc = 'converted_from {}'.format(name) if name is not None else ''
    model_proto = g.make_model(doc)

    return model_proto
